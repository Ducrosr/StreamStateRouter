"""OBS WebSocket integration."""
