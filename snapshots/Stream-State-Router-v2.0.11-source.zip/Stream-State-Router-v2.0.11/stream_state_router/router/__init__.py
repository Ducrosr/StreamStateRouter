"""Foreground routing primitives."""
